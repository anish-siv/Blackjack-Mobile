import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.ArrayList;
import java.util.Collections;

public class Deck extends Actor {
    int[] cardList = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13};
    String cardName;
    int index;
    private ArrayList<Card> deck;

    public Deck() {
        this.deck = new ArrayList<Card>();
        resetDeck();
        shuffleDeck();
    }

    private void resetDeck() {
        deck.clear();
        String[] cardTypes = {"Hearts", "Diamonds", "Clubs", "Spades"};
        for (String type : cardTypes) {
            for (int i = 1; i <= 13; i++) {
                deck.add(new Card(i,false));
            }
        }
    }

    public void shuffleDeck() {
        Collections.shuffle(deck);
    }

    public Card draw(boolean visible) {
        index = Greenfoot.getRandomNumber(13) + 1;
        Card newCard = new Card(index, visible);
        return newCard;
    }

    public Card getCard() {
        if (!deck.isEmpty()) {
            int index = Greenfoot.getRandomNumber(deck.size());
            return deck.remove(index);
        } else {
            return null; // No more cards in the deck
        }
    }
}
